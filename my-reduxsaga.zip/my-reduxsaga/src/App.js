import React, { Component } from 'react'

import { connect } from "react-redux";
import { fetchData } from "./redux/actions";

export class App extends Component {
 constructor(props) {
   super(props)
 
   this.state = {
      
   }
   this.handleFetchdata = this.handleFetchdata.bind(this)
 }
 handleFetchdata(){
   this.props.fetchData(2)
 }
 
  render() {
    return (
      <div>
        <button className='btn btn-primary' onClick={this.handleFetchdata}> Fetch</button>
        <div>

        </div>
      </div>
    )
  }
}
 const mapStateToProps = (state) => {
   return{
     user:state.fetchDataReducer.user,
     error:state.fetchDataReducer.error
   }
 }

 const mapDispatchToProps = (dispatch) => {
  return{
    fetchData:(id)=>{
      dispatch(fetchData())
    }
  }
}
 


export default connect(mapStateToProps, mapDispatchToProps)(App)
