import {combineReducers} from 'redux';
import  fetchDataReducer  from './fetchDataReducer'


const RootReducer = combineReducers({
   fetchDataReducer
})

export default RootReducer